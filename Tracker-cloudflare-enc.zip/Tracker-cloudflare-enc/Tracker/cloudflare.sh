cd modules
python3 cloudflare.cpython-311.pyc